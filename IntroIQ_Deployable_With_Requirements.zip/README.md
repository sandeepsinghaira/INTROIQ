
# AI Cold Email Assistant (Flask + Frontend)

## 🛠 Features
- AI email generation
- JWT-based signup/login
- Save user prompts
- Stripe and Razorpay integration
- Minimal frontend and clean layout

## 📦 How to Deploy

1. **Install dependencies**
```bash
cd backend
pip install -r requirements.txt
```

2. **Run the server**
```bash
python app.py
```

3. **Open index.html** in any browser (from `/frontend` folder)

## 🔐 .env Setup
Copy `.env.example` to `.env` and update `SECRET_KEY`.

## ⚙️ Notes
- Stripe/Razorpay are mocked
- Replace `generate_email` logic with OpenAI API call
